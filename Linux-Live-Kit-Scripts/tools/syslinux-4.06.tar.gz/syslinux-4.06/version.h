#define VERSION 4.06
#define VERSION_STR "4.06"
#define VERSION_MAJOR 4
#define VERSION_MINOR 6
#define YEAR 2012
#define YEAR_STR "2012"
