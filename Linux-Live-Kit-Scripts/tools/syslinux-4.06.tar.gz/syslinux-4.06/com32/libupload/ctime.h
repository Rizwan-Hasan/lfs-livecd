#ifndef CTIME_H
#define CTIME_H

#include <inttypes.h>

uint32_t posix_time(void);

#endif /* CTIME_H */
